// 201724651 KIM JANGHWAN

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <getopt.h>
#include "cachelab.h"

typedef struct {
	bool isValid;
	int tag;
	int tStamp;
} Line;

typedef struct {
	Line *lines;
} Set;

typedef struct {
	Set *sets;
	size_t setNum;
	size_t lineNum;
} Cache;

int setBits = 0, blockBits = 0;
size_t hits = 0, misses = 0, evictions = 0;
Cache cach = {};

void simulate(int address);
void update(Set *set, size_t lineNum);

int main(int argc, char *argv[]) {
	FILE *file = 0;
	for (int opt; (opt = getopt(argc, argv, "s:E:b:t:")) != -1;) {
		switch (opt) {
			case 's':
				setBits = atoi(optarg);
				cach.setNum = 2 << setBits;
				break;
			case 'E':
				cach.lineNum = atoi(optarg);
				break;
			case 'b':
				blockBits = atoi(optarg);
				break;
			case 't':
				if (!(file = fopen(optarg, "r"))) return 1; 
				break;
			default:
				return 1;
		}
	}
	if (!file || !setBits || !blockBits || !cach.lineNum ) return 1;
	
	cach.sets = malloc(sizeof(Set) * cach.setNum);
	for (int i = 0; i < cach.setNum; i++) {
		cach.sets[i].lines = calloc(sizeof(Line), cach.lineNum);
	}

	int address; char input;

	while (fscanf(file, " %c %x %*c %*d", &input, &address) != EOF) {
		if (input == 'I') continue;

		simulate(address);
		
		if (input == 'M') simulate(address);
	}
	printSummary(hits, misses, evictions);

	fclose(file);

	for (size_t i = 0; i < cach.setNum; i++) free(cach.sets[i].lines);
	
	free(cach.sets);
	
	return 0;
}

void simulate(int address) {

	int tag = address >> (setBits + blockBits);
	tag = (tag & 0xffffffff);

	size_t setIndex = (0x7fffffff >> (31 - setBits));
	setIndex = setIndex & (address >> blockBits);

	Set *set = &cach.sets[setIndex];

	for (size_t i = 0; i < cach.lineNum; i++) {
		Line* line = &set->lines[i];
		
		if (!line->isValid) continue;
		if (line->tag != tag) continue;
		
		hits++;
		update(set, i);
		
		return;
	}
	misses++;

	for (size_t i = 0; i < cach.lineNum; i++) {
		Line* line = &set->lines[i];
		
		if (line->isValid) continue;

		line->tag = tag;
		line->isValid = true;
		update(set, i);
		
		return;
	}
	evictions++;

	for (size_t i = 0; i < cach.lineNum; i++) {
		Line* line = &set->lines[i];

		if (line->tStamp) continue;

		line->tag = tag;
		line->isValid = true;
		update(set, i);
		
		return;
	}
}

void update(Set *set, size_t lineNum) {
	Line *line = &set->lines[lineNum];
	
	for (size_t i = 0; i < cach.lineNum; i++) {
		Line *pos = &set->lines[i];
		
		if (!pos->isValid) continue;
		if (pos->tStamp <= line->tStamp) continue;
				
		pos->tStamp--;
	}

	line->tStamp = cach.lineNum - 1;
}
