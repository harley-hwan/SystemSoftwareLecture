// 201724651 KIM JANGHWAN

/* trans.c - Matrix transpose B = A^T
 *
 * Each transpose function must have a prototype of the form:
 * void trans(int M, int N, int A[N][M], int B[M][N]);
 *
 * A transpose function is evaluated by counting the number of misses
 * on a 1KB direct mapped cache with a block size of 32 bytes.
 */ 
#include <stdio.h>
#include "cachelab.h"
typedef void (*block_t)(int M, int N, int A[N][M], int B[M][N], int row, int col);
void square(int M, int N, int A[N][M], int B[M][N], int row, int col);
void square2(int M, int N, int A[N][M], int B[M][N], int row, int col);
void check(int M, int N, int A[N][M], int B[M][N], int row, int col);

int is_transpose(int M, int N, int A[N][M], int B[M][N]);

/* 
 * transpose_submit - This is the solution transpose function that you
 *     will be graded on for Part B of the assignment. Do not change
 *     the description string "Transpose submission", as the driver
 *     searches for that string to identify the transpose function to
 *     be graded. 
 */
char transpose_submit_desc[] = "Transpose submission";
void transpose_submit(int M, int N, int A[N][M], int B[M][N])
{
	block_t block;
	if(M==32 && N==32)	block = square;
	else if(M==64 && N==64)	block = square2;
	else			block = check;

	for(int i=0; i <N; i+=8){
		for(int j=0; j<M; j+=8){
			block(M, N, A, B, i, j);
		}
	}
}

void square(int M, int N, int A[N][M], int B[M][N], int row, int col){
	if(row != col){ return check(M, N, A, B, row, col); }

	for(int i=row; i<row +8 && i<N; ++i){
		int temp = A[i][i];
		for(int j=col; j<col+8 && j<M; ++j){
			if(i==j) continue;
			B[j][i] = A[i][j];
		}
		B[i][i] = temp;
	}
}

void square2(int M, int N, int A[N][M], int B[M][N], int row, int col){
	int *temp = &A[col][row+4];
	int a = temp[0], b=temp[1], c=temp[2], d=temp[3];

	// upper part of output

	for(int i=0; i<8; ++i){
		int *temp = &A[col+i][row];
		int a = temp[0], b=temp[1], c=temp[2], d=temp[3];
		temp = &B[row][col+i];
		temp[0] = a; temp[64] = b; temp[128] = c; temp[192] = d;
	}

	// lower part of output

	for(int i=7; i>0; --i){
		int *temp = &A[col+i][row+4];
		int a = temp[0], b = temp[1], c = temp[2], d = temp[3];
		temp = &B[row+4][col+i];
		temp[0] = a; temp[64]=b; temp[128]=c; temp[192]=d;
	}

	temp = &B[row+4][col];
	temp[0] = a; temp[64] = b; temp[128] = c; temp[192] = d;
}

void check(int M, int N, int A[N][M], int B[M][N], int row, int col){
	for(int i=col; i<col+8 && i<M; ++i){
		for(int j=row; j<row+8 && j<N; ++j){
			B[i][j] = A[j][i];
		}
	}
}

	

/* 
 * You can define additional transpose functions below. We've defined
 * a simple one below to help you get started. 
 */ 

/* 
 * trans - A simple baseline transpose function, not optimized for the cache.
 */
char trans_desc[] = "Simple row-wise scan transpose";
void trans(int M, int N, int A[N][M], int B[M][N])
{
    int i, j, tmp;

    for (i = 0; i < N; i++) {
        for (j = 0; j < M; j++) {
            tmp = A[i][j];
            B[j][i] = tmp;
        }
    }    

}

/*
 * registerFunctions - This function registers your transpose
 *     functions with the driver.  At runtime, the driver will
 *     evaluate each of the registered functions and summarize their
 *     performance. This is a handy way to experiment with different
 *     transpose strategies.
 */
void registerFunctions()
{
    /* Register your solution function */
    registerTransFunction(transpose_submit, transpose_submit_desc); 

    /* Register any additional transpose functions */
    registerTransFunction(trans, trans_desc); 

}

/* 
 * is_transpose - This helper function checks if B is the transpose of
 *     A. You can check the correctness of your transpose by calling
 *     it before returning from the transpose function.
 */
int is_transpose(int M, int N, int A[N][M], int B[M][N])
{
    int i, j;

    for (i = 0; i < N; i++) {
        for (j = 0; j < M; ++j) {
            if (A[i][j] != B[j][i]) {
                return 0;
            }
        }
    }
    return 1;
}

